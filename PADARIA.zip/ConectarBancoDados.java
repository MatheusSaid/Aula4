import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConectarBancoDados extends JFrame implements ActionListener {
    private JTextField campoNome;
    private JButton botaoConectar;
    private Connection conexao;

    public ConectarBancoDados() {
        super("Exemplo de Conexão com Banco de Dados");
        
        campoNome = new JTextField(20);
        botaoConectar = new JButton("Conectar ao Banco de Dados");
        botaoConectar.addActionListener(this);

        JPanel painel = new JPanel(new FlowLayout());
        painel.add(new JLabel("Nome: "));
        painel.add(campoNome);
        painel.add(botaoConectar);

        add(painel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ConectarBancoDados exemplo = new ConectarBancoDados();
            exemplo.setVisible(true);
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == botaoConectar) {
            String nome = campoNome.getText();

            // Configuração da conexão com o banco de dados
            String url = "jdbc:mysql://localhost:3306/seu_banco_de_dados";
            String usuario = "seu_usuario";
            String senha = "sua_senha";

            try {
                // Estabelece a conexão com o banco de dados
                conexao = DriverManager.getConnection(url, usuario, senha);

                // Executa uma operação no banco de dados (por exemplo, inserção de dados)
                String sql = "INSERT INTO tabela_exemplo (nome) VALUES (?)";
                PreparedStatement preparedStatement = conexao.prepareStatement(sql);
                preparedStatement.setString(1, nome);
                preparedStatement.executeUpdate();

                JOptionPane.showMessageDialog(this, "Dados inseridos com sucesso!");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erro ao conectar ou inserir dados no banco de dados.");
            } finally {
                try {
                    if (conexao != null) {
                        conexao.close();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
